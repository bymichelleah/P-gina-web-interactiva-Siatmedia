document.addEventListener('DOMContentLoaded', function () {
    // Referencias a elementos del DOM
    const agregarProductoBtn = document.getElementById('agregar-producto');
    const limpiarCestaBtn = document.getElementById('limpiar-cesta');
    const actualizarBtn = document.getElementById('actualizar');
    const tablaProductosCuerpo = document.getElementById('tabla-productos-cuerpo');
    const cantidadProductosElem = document.getElementById('cantidad-productos');
    const valorVentaElem = document.getElementById('valor-venta');
    const igvElem = document.getElementById('igv');
    const totalPagarElem = document.getElementById('total-pagar');

    // Evento para agregar un producto a la tabla
    agregarProductoBtn.addEventListener('click', function () {
        const formProducto = document.getElementById('form-producto');
        const codigoBarras = formProducto['codigo-barras'].value;
        const nombre = formProducto['nombre'].value;
        const precio = parseFloat(formProducto['precio'].value);
        const stock = parseInt(formProducto['stock'].value);

        // Verifica que todos los campos estén completos
        if (codigoBarras && nombre && precio && stock) {
            // Crear una nueva fila en la tabla de productos
            const nuevaFila = document.createElement('tr');

            nuevaFila.innerHTML = `
                <td>${tablaProductosCuerpo.rows.length + 1}</td>
                <td><input type="number" name="cantidad[]" class="cantidad" value="1" min="1" max="${stock}"></td>
                <td>${codigoBarras}</td>
                <td>${nombre}</td>
                <td>${precio.toFixed(2)}</td>
                <td class="total">${precio.toFixed(2)}</td>
            `;

            // Agregar la nueva fila a la tabla
            tablaProductosCuerpo.appendChild(nuevaFila);
            // Limpiar el formulario de producto
            formProducto.reset();
            // Actualizar los totales
            actualizarTotales();
        } else {
            // Mostrar una alerta si algún campo está incompleto
            alert('Por favor, complete todos los campos del producto.');
        }
    });

    // Evento para limpiar la cesta (tabla de productos)
    limpiarCestaBtn.addEventListener('click', function () {
        // Limpiar el contenido del cuerpo de la tabla
        tablaProductosCuerpo.innerHTML = '';
        // Actualizar los totales
        actualizarTotales();
    });

    // Evento para actualizar los totales cuando se hace clic en el botón "Actualizar"
    actualizarBtn.addEventListener('click', actualizarTotales);

    // Evento para actualizar los totales cuando se cambia la cantidad de un producto
    tablaProductosCuerpo.addEventListener('input', function (e) {
        if (e.target.classList.contains('cantidad')) {
            // Actualizar los totales si se cambia el valor de una cantidad
            actualizarTotales();
        }
    });

    // Función para actualizar los totales
    function actualizarTotales() {
        let cantidadProductos = 0;
        let valorVenta = 0;
        const filas = tablaProductosCuerpo.querySelectorAll('tr');

        // Calcular el total de productos y el valor de venta
        filas.forEach(fila => {
            const cantidad = parseInt(fila.querySelector('.cantidad').value);
            const precioUnitario = parseFloat(fila.cells[4].textContent);
            const total = cantidad * precioUnitario;

            // Actualizar el total de la fila
            fila.querySelector('.total').textContent = total.toFixed(2);
            cantidadProductos += cantidad;
            valorVenta += total;
        });

        // Calcular IGV (18%) y el total a pagar
        const igv = valorVenta * 0.18;
        const totalPagar = valorVenta + igv;

        // Actualizar los elementos del DOM con los nuevos valores
        cantidadProductosElem.textContent = cantidadProductos;
        valorVentaElem.textContent = `S/ ${valorVenta.toFixed(2)}`;
        igvElem.textContent = `S/ ${igv.toFixed(2)}`;
        totalPagarElem.textContent = `S/ ${totalPagar.toFixed(2)}`;
    }
});

